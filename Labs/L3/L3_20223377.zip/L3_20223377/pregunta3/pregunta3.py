import sys

if __name__ == '__main__': 

    severidad = sys.argv[1]

    # Leer el archivo CSV 
    with open("Log_de_medidores.csv", "r") as archivo:
        contenido = archivo.read()
    
    datos = contenido.split("\n")[1:] #dividimos el contenido en líneas desde la segunda linea, lista de strings

    n_linea = 0
    comando = ""

    for dato in datos:
        indicadores = [val for val in dato.split(";")] #dividimos las lineas, se separa cada elemento individual separado por una ; 
        try:
            if (severidad == indicadores[2]): #la tercera columna
                print(dato) #se imprime solo la linea actual
                comando = input("Ingrese s para ver la siguiente incidencia o ingrese p para terminar: ")
                if(comando == "p"): #se asume que solo se ingresara s o p
                    print("Se ha terminado el programa")
                    exit(0) #acaba el programa
        except IndexError:
            print("No hay más incidencias para mostrar")
            exit(0) #acaba el programa una vez que haya terminado de buscar en todas las lineas