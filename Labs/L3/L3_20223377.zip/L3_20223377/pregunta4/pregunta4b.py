
procesadores = 0

with open("/proc/cpuinfo", "r") as f:
    data = f.read().splitlines()

for linea in data:
    if "processor" in linea:
        procesadores += 1

print(f"Numero de procesadores: {procesadores}")