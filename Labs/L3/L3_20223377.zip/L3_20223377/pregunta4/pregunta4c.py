
import time

while True: #se repetirá hasta detenerlo con ctrlC
    with open("/proc/meminfo", "r") as f:
        data = f.read().splitlines()

        dato = data[0] #observamos la primera linea
        columna = [val for val in dato.split(":       ")] #el dato numerico esta detras de un : y un espacio
        numero = [val for val in columna[1].split(" ")] #tenemos que separar el numero y el kB, que estan separados por un espacio
        MemTotal = int(numero[0])

        dato = data[1] #observamos la segunda linea
        columna = [val for val in dato.split(":        ")] #el dato numerico esta detras de un : y un espacio
        numero = [val for val in columna[1].split(" ")] #tenemos que separar el numero y el kB, que estan separados por un espacio
        MemFree = int(numero[0])
        
        memoria_disponible = (MemFree / MemTotal) * 100
        print(f"Memoria disponible: {memoria_disponible}%")
        
    time.sleep(2) #esperamos dos segundos antes de volver a imprimir la memoria
        