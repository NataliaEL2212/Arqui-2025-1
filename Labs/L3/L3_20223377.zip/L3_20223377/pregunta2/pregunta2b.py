import sys

with open("output_parte2b.txt", "w") as f:
    while True:
        for line in sys.stdin:
            f.write(line)
        