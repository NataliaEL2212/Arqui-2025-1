import sys

try: #se prueba obtener el nombre del archivo de texto
    archivo = sys.argv[1]
except IndexError: #como sale IndexError, se redirigirá lo ingresado a la terminal
    for line in sys.stdin:
        sys.stdout.write(line)

with open(archivo, "w") as f:
    while True:
        for line in sys.stdin:
            f.write(line)
        