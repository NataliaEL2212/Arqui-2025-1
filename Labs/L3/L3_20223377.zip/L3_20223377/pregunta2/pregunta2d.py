import sys

archivo_entrada = sys.argv[1]
archivo_salida = sys.argv[2]

with open(archivo_entrada, "r") as entrada, open(archivo_salida, "w") as salida:
    texto = entrada.read()
    salida.write(texto)
        