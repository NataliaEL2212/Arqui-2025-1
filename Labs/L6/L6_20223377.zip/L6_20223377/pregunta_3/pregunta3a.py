#Laboratorio 5 Pregunta 3a
#Natalia Escudero Lay 20223377

import time
from threading import Thread
from threading import Lock

sumas = []
lock = Lock()

def calcular_suma_lecturas(sensor: str):
    global sumas
    nombre_archivo = f"sensor{sensor}.csv"
    with open(nombre_archivo, "r", encoding="utf-8") as f:
        dato = f.read().splitlines() #obtenemos el contenido como una lista
    lecturas = []
    for i in range(0,len(dato)):
        lecturas.append(float(dato[i])) #convertimos de str a float
    with lock: #protegemos la variable global
        suma = sum(lecturas) #sumamos todas las lecturas del archivo
        sumas.append(suma)

if __name__ == '__main__':
    inicio = time.perf_counter()

    for i in range(0,5): #iniciamos todos los hilos
        t = Thread(target=calcular_suma_lecturas, args=(i,))
        t.start()
    for i in range(0,5): #esperamos a que todos terminen
        t.join()

    fin = time.perf_counter() #cuando todos los hilos han acabado

    for i in range(0,5): #comenzamos a imprimir los resultados
        print(f"sensor{i}.csv: {sumas[i]}")
    print(f"Total de todas las lecturas: {sum(sumas)}")
    print(f"Threading tiempo: {(fin - inicio):.6f} segundos")
    
