#Laboratorio 5 Pregunta 3b
#Natalia Escudero Lay 20223377

import time
import asyncio
import json

def calcular_suma_lecturas(sensor: str) -> float:
    nombre_archivo = f"sensor{sensor}.csv"
    with open(nombre_archivo, "r", encoding="utf-8") as f:
        dato = f.read().splitlines() #obtenemos el contenido como una lista
    lecturas = []
    for i in range(0,len(dato)):
        lecturas.append(float(dato[i])) #convertimos de str a float
    suma = sum(lecturas) #sumamos todas las lecturas del archivo

    return suma

async def main() -> list[float]:
    sumas = []
    for i in range(0,5):
        sumas.append(await asyncio.to_thread(calcular_suma_lecturas, i))
    return sumas

if __name__ == '__main__':
    inicio = time.perf_counter()

    sumas = asyncio.run(main())

    fin = time.perf_counter() #cuando todos los hilos han acabado

    for i in range(0,5): #comenzamos a imprimir los resultados
        print(f"sensor{i}.csv: {sumas[i]}")
    print(f"Total de todas las lecturas: {sum(sumas)}")
    print(f"Threading tiempo: {(fin - inicio):.6f} segundos")
    
    data = {}
    for i in range(0,5):
        data[f"sensor{i}.csv"] = sumas[i]
    data[f"total"] = sum(sumas)

    with open("sensors_summary.json", "w", encoding="utf-8") as f:
        f.write(json.dumps(data))
