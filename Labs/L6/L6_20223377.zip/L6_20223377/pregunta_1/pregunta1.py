#Laboratorio 5 Pregunta 1
#Natalia Escudero Lay 20223377

import statistics
from threading import Thread
from threading import Lock
from random import randint

valores = []
media = 0
desviacion = 0

lock = Lock()

def simular_sensor():
    global valores #lista es una variable global
    for i in range(0,10000):
        with lock: #protegemos la lista para que no sea accedida al mismo tiempo
            valores.append(float(randint(0,100)))  

def calcular_media():
    global media #variable global
    media = statistics.mean(valores)

def calcular_desv():
    global desviacion #variable global
    desviacion = statistics.stdev(valores)

if __name__ == '__main__':
    for i in range(0,10): #inicializar todos los hilos
        t = Thread(target=simular_sensor)
        t.start()
    for i in range(0,10): #esperar a que todos los hilos terminen
        t.join()
    mean = Thread(target=calcular_media)
    dev = Thread(target=calcular_desv)

    #iniciamos los hilos y garantizamos que terminen
    mean.start()
    dev.start()
    mean.join()
    dev.join()

    #guardando e imprimiendo los resultados
    resultados = f"Media: {media:.4f}\nDesviación: {desviacion:.4f}"
    print(resultados)
    with open("resultados.txt", "w", encoding="utf-8") as f:
        f.write(resultados)