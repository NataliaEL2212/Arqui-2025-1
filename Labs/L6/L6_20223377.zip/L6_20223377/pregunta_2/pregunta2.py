#Laboratorio 5 Pregunta 2
#Natalia Escudero Lay 20223377

import time
import csv
import asyncio
import datetime
from random import randint

async def genera_evento(id):
    delay = randint(1,4)
    timestamp = datetime.datetime.now().isoformat()
    await asyncio.sleep(delay)
    tupla = f"{id},{delay},{timestamp}"
    return tupla

async def main() -> list[float]:
    resultados = await asyncio.gather(*(genera_evento(id) for id in range(0,5)))
    
    return resultados

if __name__ == '__main__':

    inicio = time.perf_counter()
    resultados = asyncio.run(main())
        
    # Escribir los resultados en el CSV
    with open("eventos.csv", "w", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["evento", "delay", "timestamp"])
        for i in range(0,5):
            f.write(f"{resultados[i]}\n")

    fin = time.perf_counter()

    print(f"Tiempo total de registro: {(fin - inicio):.6f} segundos")
