#Laboratorio 5 Pregunta 3
#Natalia Cristina Escudero Lay 20223377

import asyncio
import time
from random import randint

async def simular_SMS(t_envio: int, t_recepcion: int):
    latencia = t_envio + t_recepcion
    await asyncio.sleep(latencia / (10*10*10)) #esperamos el tiempo de la latencia en ms
    print(f"La corrutina de la tecnología SMS tuvo una latencia de {latencia} ms.")

async def simular_3G(t_idayvuelta: int, t_recepcion: int):
    latencia = 2*(t_idayvuelta + t_recepcion)
    await asyncio.sleep(latencia / (10*10*10)) #esperamos el tiempo de la latencia en ms
    print(f"La corrutina de la tecnología 3G tuvo una latencia de {latencia} ms.")

async def simular_satelital(ret_propagacion: int, t_procesamiento: int):
    latencia = 2*ret_propagacion + t_procesamiento
    await asyncio.sleep(latencia / (10*10*10)) #esperamos el tiempo de la latencia en ms
    print(f"La corrutina de la tecnología Satelital tuvo una latencia de {latencia} ms.")

async def main():
    await asyncio.gather(simular_SMS(randint(10,100),randint(10,100)),simular_3G(randint(100,300),randint(10,100)), simular_satelital(randint(500,700),randint(10,100))) #colocamos como entradas numeros aleatorios

if __name__ == '__main__':
    asyncio.run(main())
