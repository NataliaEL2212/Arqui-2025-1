#Laboratorio 5 Pregunta 4
#Natalia Cristina Escudero Lay 20223377

import asyncio

rutas_posibles = [
	"LPC",
	"LPAHC",
	"LPAOHC",
	"LOAPC",
	"LOAHC",
	"LOHC",
	"LOHAPC",
	"LAPC",
	"LAOHC",
	"LAHC"
]

distancias = {
	"LP": 14,
	"LC": 10,
    "LA": 10,
	"LO": 8,
	"PC": 18,
	"PA": 3,
	"OA": 25,
	"OH": 5,
	"AP": 3,
	"AO": 25,
	"AH": 2,
	"HA": 2,
	"HC": 10
}

async def calcular_ruta(ruta: str) -> float:
    tiempo_ruta = 0
    destinos = list(ruta)

    for i in range(0,len(destinos)-1): #se analizan los pares de destinos. Ejem: LPC son dos viajes, es decir 3 ubicaciones - 1
        for x in distancias: #se analizara cada combinacion de dos distancias
            if f"{destinos[i]}{destinos[i+1]}" == x: #si la ruta equivale al key de la distancia
                tiempo_ruta = distancias[x] + tiempo_ruta
                await asyncio.sleep(distancias[x] / (10*10*10)) #esperamos el tiempo de la viaje en ms
    
    return f"{ruta}:{tiempo_ruta}"

async def main(rutas_posibles: list[str]) -> float:
    rutas = await asyncio.gather(*(calcular_ruta(ruta) for ruta in rutas_posibles)) #esperamos que se calculen todas las rutas
    ruta_ideal = ""
    tiempo_ideal = 1000 #tiempo de comparacion inicial muy grande
    for ruta in rutas: #se verifican todas las rutas analizadas
        datos = ruta.split(":") #separamos los dos datos
        if int(datos[1]) << tiempo_ideal: #comparamos hasta obtener el tiempo menor
            tiempo_ideal = int(datos[1]) #pasamos a int
            ruta_ideal = datos[0] #se mantiene

    return f"{ruta_ideal}:{tiempo_ideal}"

if __name__ == "__main__":
    
    ruta_ideal = asyncio.run(main(rutas_posibles))

    resultado = ruta_ideal.split(":") #dividimos el nombre de la ruta con su tiempo
    
    print(f"La ruta más corta es {resultado[0]} con una duración de {resultado[1]} horas.")