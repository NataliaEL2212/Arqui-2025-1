
rutas_posibles = [
	"LPC",
	"LPAHC",
	"LPAOHC",
	"LOAPC",
	"LOAHC",
	"LOHC",
	"LOHAPC",
	"LIMAPC",
	"LAOHC",
	"LAHC"
]

distancias = {
	"LP": 14,
	"LC": 10,
	"LO": 8,
	"PC": 18,
	"PA": 3,
	"OA": 25,
	"OH": 5,
	"AP": 3,
	"AO": 25,
	"AH": 2,
	"HA": 2,
	"HC": 10
}

if __name__ == "__main__":
	"""Escriba su código aquí"""
	pass
