#Laboratorio 5 Pregunta 2a
#Natalia Cristina Escudero Lay 20223377

import time
import threading
from urllib.request import urlopen

def download(url,file_name):
	with urlopen(url) as page:
		image_data = page.read()
		with open(file_name,'wb') as f:
			f.write(image_data)

def descarga_secuencial():
	for i in range(1,30):
		url = f'https://raw.githubusercontent.com/SebastianMerino/Threading/main/images/{i:02}.png'
		file_name = f'{i:02}.png'
		download(url,file_name)

if __name__=='__main__':
	inicio = time.perf_counter()
	descarga_secuencial()
	fin = time.perf_counter()
	print(f"Tiempo total de ejecucion: {(fin - inicio):.6f} segundos")

'Tiempo total de ejecucion: 0.894522 segundos'