#Laboratorio 5 Pregunta 2c
#Natalia Cristina Escudero Lay 20223377

import time
import threading
from urllib.request import urlopen

def download_images(inicio:int, final:int):
    for i in range(inicio,final+1):
        url = f'https://raw.githubusercontent.com/SebastianMerino/Threading/main/images/{i:02}.png'
        file_name = f'{i:02}.png'
        with urlopen(url) as page:
            image_data = page.read()
            with open(file_name,'wb') as f:
                f.write(image_data)

if __name__=='__main__':
    inicio = time.perf_counter()

    t1=threading.Thread(target=download_images, args=(1,9))
    t2=threading.Thread(target=download_images, args=(10,19))
    t3=threading.Thread(target=download_images, args=(20,29))

    t1.start()
    t2.start()
    t3.start()
    t1.join()
    t2.join()
    t3.join() #esperar a que los tres hilos terminen antes de hacer el perf_counter

    fin = time.perf_counter()

    print(f"Tiempo total de ejecucion: {(fin - inicio):.6f} segundos")

    'Tiempo total de ejecucion: 0.175606 segundos'

    #A comparación de los dos resultados anteriores, este programa es el más rápido en su ejecución, superando con 0.70792 s al primero y 0.186602 s al segundo. Los resultados al usar sólo tres hilos son mejores que con 29 hilos, ya que todos los hilos ocupan el mismo
    #espacio de memoria, la cual se saturará. Lo mejor es utilizar una cantidad limitada de hilos y cuando concluya el procesamiento de una imagen, pueda pasar a la siguiente; es un método más efectivo en este caso. Además, el mismo Python para evitar Race Condition
    #puede encontrarse ralentizando o mitigando el uso de hilos.

