#Laboratorio 5 Pregunta 2b
#Natalia Cristina Escudero Lay 20223377

import time
import threading
from urllib.request import urlopen

def download(i: int):
    url = f'https://raw.githubusercontent.com/SebastianMerino/Threading/main/images/{i:02}.png'
    file_name = f'{i:02}.png'
    with urlopen(url) as page:
        image_data = page.read()
        with open(file_name,'wb') as f:
            f.write(image_data)

if __name__=='__main__':
    inicio = time.perf_counter()

    for i in range(1,30): #iniciamos todos los hilos
        t=threading.Thread(target=download, args=(i,))
        t.start()

    for i in range(1,30): #esperamos a que todos los hilos terminen antes de hacer el perf_counter
        t.join()

    fin = time.perf_counter()

    print(f"Tiempo total de ejecucion: {(fin - inicio):.6f} segundos")

'Tiempo total de ejecucion: 0.362208 segundos'

#A comparación del resultado anterior, donde obtuvimos un tiempo de ejecución de 0.894522 segundos, podemos observar que la diferencia de tiempo es de 0.532314 segundos. Es decir, la diferencia del tiempo total de ejecución es considerablemente grande y por ende, el
#uso de hilos es eficiente en el programa.