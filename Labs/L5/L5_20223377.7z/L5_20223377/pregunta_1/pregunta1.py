#Laboratorio 5 Pregunta 1
#Natalia Cristina Escudero Lay 20223377

from threading import Thread
from random import randint

def calcular_suma(numeros: list[int], resolucion: list[int]):
    resolucion.append(sum(numeros)) #agregamos la nueva suma a la lista

if __name__ == '__main__':
    numeros = []
    resolucion = []

    for i in range(0,100): #generamos una lista de 100 numeros aleatorios
        numeros.append(randint(0,10)) #numeros aleatorios entre 0 y 1000

    t1 = Thread(target=calcular_suma, args=(numeros[0:49], resolucion)) #primera mitad
    t2 = Thread(target=calcular_suma, args=(numeros[50:99], resolucion)) #segunda mitad

    t1.start()
    t2.start()
    t1.join()
    t2.join() #esperamos a que ambos hilos concluyan

    suma_final = sum(resolucion) #obtenemos la suma final

    print(f"La suma final es {suma_final}")